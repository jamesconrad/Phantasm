#pragma once

#define NETWORKING_API __declspec(dllexport) 
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#include <WinSock2.h>
#include<stdio.h>
#include <string>

#pragma comment(lib,"ws2_32.lib") //Winsock Library

#define SERVER "10.160.31.17"
#define BUFLEN 512  //Max length of buffer
#define PORT 8888   //The port on which to listen for incoming data

class NETWORKING_API LocalSocket
{
public:
	struct sockaddr_in socketAddress;
	struct sockaddr_in remoteAddress;
	SOCKET socketID;
	int socketSize;
	int portNumber;

	LocalSocket(int givenPort);
	~LocalSocket();

};

extern "C"
{
	NETWORKING_API LocalSocket* Initialize(int givenPort);
	NETWORKING_API int Send(LocalSocket &givenSocket, char* buffer, int bufferLength, char* givenAddress, int givenPort);
	NETWORKING_API int Receive(LocalSocket &givenSocket, char* receiveBuffer, int bufferLength);
	NETWORKING_API void CloseDown(LocalSocket* givenSocket);
	NETWORKING_API void GetRemoteAddress(LocalSocket& givenSocket, char* buffer, int bufferLength);
}