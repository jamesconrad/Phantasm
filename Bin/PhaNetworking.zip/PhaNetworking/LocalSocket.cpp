#include "LocalSocket.h"

#include <exception>


LocalSocket::LocalSocket(int givenPort)
{
	WSADATA wsaData;
	WSAStartup(MAKEWORD(2, 2), &wsaData);

	socketID = socket(AF_INET, SOCK_DGRAM, 0);
	if (socketID == INVALID_SOCKET)
	{
		printf("Socket create failed: %d\n", WSAGetLastError());
	}
	u_long mode = 1;  // 1 to enable non-blocking socket. 0 for blocking.
	ioctlsocket(socketID, FIONBIO, &mode);
	int check = WSAGetLastError();

	remoteAddress.sin_family = socketAddress.sin_family = AF_INET;
	socketAddress.sin_addr.s_addr = INADDR_ANY;
	remoteAddress.sin_port = socketAddress.sin_port = htons(givenPort);

	if (bind(socketID, (struct sockaddr *)&socketAddress, sizeof(socketAddress)) == SOCKET_ERROR)
	{
		printf("Bind failed with error code : %d", WSAGetLastError());
	}

	socketSize = sizeof(socketAddress);
}

LocalSocket::~LocalSocket()
{
	shutdown(socketID, SD_BOTH);
	closesocket(socketID);
	WSACleanup();
}

extern "C"
{
	LocalSocket* Initialize(int givenPort)
	{
		return (new LocalSocket(givenPort));
	}

	int Send(LocalSocket &givenSocket, char* buffer, int bufferLength, char* givenAddress, int givenPort)
	{
		givenSocket.remoteAddress.sin_addr.S_un.S_addr = inet_addr(givenAddress);
		givenSocket.remoteAddress.sin_port = htons(givenPort);
		int sentBytes = sendto(givenSocket.socketID, buffer, bufferLength, 0, (sockaddr*)&givenSocket.remoteAddress, sizeof(givenSocket.remoteAddress));
		if (sentBytes == SOCKET_ERROR)
		{
			return WSAGetLastError();
		}
		return sentBytes;
	}

	int Receive(LocalSocket &givenSocket, char* receiveBuffer, int bufferLength)
	{
		memset(receiveBuffer, '\0', bufferLength);
		int sizeTemp = sizeof(givenSocket.remoteAddress);
		sizeTemp = recvfrom(givenSocket.socketID, receiveBuffer, bufferLength, 0, (sockaddr *)&givenSocket.remoteAddress, &sizeTemp);
		if (sizeTemp == SOCKET_ERROR)
		{
			return WSAGetLastError();
		}
		return sizeTemp;
	}

	void CloseDown(LocalSocket* givenSocket)
	{
		if (givenSocket != nullptr)
		{
			delete givenSocket;
			givenSocket = nullptr;
		}
	}

	void GetRemoteAddress(LocalSocket& givenSocket, char* buffer, int bufferLength)
	{
		memset(buffer, '\0', bufferLength);
		strcpy(buffer, inet_ntoa(givenSocket.remoteAddress.sin_addr));
		return;
	}
}