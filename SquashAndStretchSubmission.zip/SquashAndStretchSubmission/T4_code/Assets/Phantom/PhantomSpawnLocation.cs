﻿using UnityEngine;
using System.Collections;

public class PhantomSpawnLocation : MonoBehaviour
{
    // Implement this OnDrawGizmo if you want to draw gizmos for the object
    public void OnDrawGizmosSelected()
    {

    }


}
