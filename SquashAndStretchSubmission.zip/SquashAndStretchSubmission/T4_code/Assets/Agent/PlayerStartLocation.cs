﻿using UnityEngine;
using System.Collections;

public class PlayerStartLocation : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    // Implement this OnDrawGizmos if you want to draw gizmos that are also pickable and always drawn
    public void OnDrawGizmosSelected()
    {

    }
}
